package com.example.macstudent.nav;


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnSubmit;
   DBHelper dbHelper;
    SQLiteDatabase navneetDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);


        dbHelper = new DBHelper(this);

    }


    @Override
    public void onClick(View view) {
        if (view.getId() == btnSubmit.getId()){

            insertUser();
            displayData();

        }
    }


    private void insertUser(){
        EditText edtName = (EditText) findViewById(R.id.edtName);
        EditText edtPhone = (EditText) findViewById(R.id.edtPhone);
        EditText edtEmail = (EditText) findViewById(R.id.edtEmail);
        EditText edtPassword = (EditText) findViewById(R.id.edtPassword);


        String name = edtName.getText().toString();
        String phone = edtPhone.getText().toString();
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();


        ContentValues cv = new ContentValues();
        cv.put("Name", name);
        cv.put("Phone", phone);
        cv.put("Email", email);
        cv.put("Password", password);

        try{
            navneetDB = dbHelper.getWritableDatabase();
            navneetDB.insert("UserInfo",
                    null, cv);
            Log.v("Insert record","Successful");

        }catch (Exception e){
            Log.e("Insert User",e.getMessage());

        }
        navneetDB.close();
    }

    private void displayData(){

        try{
            navneetDB = dbHelper.getReadableDatabase();

            String columns[] = {"Name", "Phone",
                    "Email", "Password", "DOB"};

            Cursor cursor = navneetDB.query("UserInfo"
                    ,columns,null,null,
                    null,null,null);

            while (cursor.moveToNext()){
                String name = cursor.getString
                        (cursor.getColumnIndex("Name"));
                String email = cursor.getString(
                        cursor.getColumnIndex("Email")
                );

                String phone = cursor.getString(
                        cursor.getColumnIndex("Phone")
                );

                String password = cursor.getString(
                        cursor.getColumnIndex("Password")
                );





                Toast.makeText(this,UserInfo,
                        Toast.LENGTH_LONG).show();

            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        navneetDB.close();

    }

    /**
     * Created by macstudent on 2018-04-09.
     */

    public static class DBHelper {
    }
}
